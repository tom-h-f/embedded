def main():
    print("Hello from iot-cli!")


if __name__ == "__main__":
    main()
